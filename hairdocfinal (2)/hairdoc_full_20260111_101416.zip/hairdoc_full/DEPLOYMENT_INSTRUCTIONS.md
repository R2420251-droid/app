# HostAfrica Deployment Instructions

## Quick Start Guide

### 1. Database Setup
1. Log into **cPanel** on HostAfrica
2. Go to **MySQL Databases**
3. Create a new database (e.g., `yourname_hairdoc`)
4. Create a new user and password
5. Add user to database with **ALL PRIVILEGES**
6. Go to **phpMyAdmin** and import `backend/schema.sql`

### 2. Backend Deployment

#### Option A: Using Node.js App in cPanel (Recommended)
1. In cPanel, go to **Setup Node.js App**
2. Create a new application
3. Set Node.js version to 18+ (or latest available)
4. Set Application root to your backend directory (e.g., `public_html/api`)
5. Set Application startup file to `server.js`
6. Set Application URL to your desired path (e.g., `/api` or subdomain)
7. Upload backend files to the application root
8. In the application settings, set environment variables:
   - `DB_HOST` - Usually `localhost`
   - `DB_USER` - Your database user
   - `DB_PASSWORD` - Your database password
   - `DB_NAME` - Your database name
   - `JWT_SECRET` - Generate with: `openssl rand -base64 32`
   - `PORT` - Usually set automatically by HostAfrica
   - `NODE_ENV` - `production`
9. Click **Run NPM install** (or run `npm install` via SSH)
10. Click **Restart App**

#### Option B: Manual Deployment via SSH
1. Upload backend files to your server
2. SSH into your server
3. Navigate to backend directory
4. Copy `.env.example` to `.env` and configure it
5. Run `npm install --production`
6. Run `npm run migrate` (if migrations exist)
7. Use PM2 or similar to run: `npm start`

### 3. Frontend Deployment
1. Upload all files from the `frontend/` directory to your `public_html/` directory
2. Ensure `index.html` is in the root of `public_html/`
3. Configure your backend API URL if needed (should use relative paths)

### 4. Configuration
1. Ensure backend `.env` file has correct database credentials
2. Generate a strong `JWT_SECRET`:
   ```bash
   openssl rand -base64 32
   ```
3. Update CORS settings in `backend/server.js` if needed

### 5. Verify Deployment
1. Check backend health: `https://yourdomain.com/api/health`
2. Visit frontend: `https://yourdomain.com`
3. Test login and basic functionality

## File Structure After Deployment

```
public_html/
├── index.html (frontend)
├── assets/ (frontend built files)
└── api/ (backend - if using subdirectory)
    ├── server.js
    ├── package.json
    ├── routes/
    └── ...
```

Or separate:

```
/home/user/
├── backend/
│   ├── server.js
│   └── ...
└── public_html/
    ├── index.html
    └── assets/
```

## Troubleshooting

### Backend won't start
- Check Node.js version (need 16+)
- Check environment variables are set correctly
- Check database connection details
- Check logs in `backend/logs/`

### Frontend can't connect to backend
- Verify backend URL in frontend code
- Check CORS settings in backend
- Verify backend is running and accessible

### Database connection errors
- Verify database credentials in `.env`
- Check database user has correct permissions
- Verify database exists

## Support Files

- `backend/API.md` - API documentation
- `backend/ENV_SETUP.md` - Environment setup guide
- `backend/DEPLOYMENT.md` - Detailed deployment guide
